# 96-hour matched-history copula vs continuous CVAE, 2026 unseen holdouts

This package contains reproducible forecasts and scores on February 9–12,
May 11–14 and July 13–16, 2026. These are twelve daily forecast issues,
scored for the 84-hour MPC horizon with 500 raw paths reduced to 50 weighted
paths using the research project's unchanged backward-deletion implementation.

**Important: the copula forecast is a MODIFIED benchmark.** Unlike the original
90-day price-recalibrated copula, it uses precisely the last 96 completed
hourly DA prices for its empirical quantile-mapping target. The 24-hour wind
analogue matching and the full pre-2026 historical reference library are
unchanged. The CVAE is the ORIGINAL frozen calibrated MPC CVAE, not the
separate thesis-style T-CVAE. This tests recent-information budget, not
identical training data or modelling flexibility.

## Run using the published project repository

Copy `code/horse_creek_copula.py` into:
`forecast_release/source_releases/horse_creek_forecasting_release/horse_creek_copula.py`
Copy `code/compare_copula_cvae.py` into:
`analysis/forecast_comparison/compare_copula_cvae.py`
Preserve the originals separately; the supplied copula module defaults to the
prior 90-day/45-day guard if `--copula-price-hours` is omitted.

From the root of the project repository:
```
python analysis/forecast_comparison/compare_copula_cvae.py --weeks feb_2026_84h spring_2026_84h summer_2026_84h --copula-price-hours 96 --seed 3714 --out benchmark_96h_seed3714
python analysis/forecast_comparison/compare_copula_cvae.py --weeks feb_2026_84h spring_2026_84h summer_2026_84h --copula-price-hours 96 --seed 13714 --out benchmark_96h_seed13714
python analysis/forecast_comparison/compare_copula_cvae.py --weeks feb_2026_84h spring_2026_84h summer_2026_84h --copula-price-hours 96 --seed 2718 --out benchmark_96h_seed2718
```
No Gurobi license is required for this forecast-only experiment.
The results contain the raw 500-ensemble and reduced 50-scenario metrics.
Use the `reduced_50` rows for the paper's decision-facing comparison.
CVAE and training checkpoints are not modified by these scripts.

**Interpretation caution:** 96 observations are a small nonparametric empirical
marginal sample. The DA-price undercoverage in May/July should not be
presented as proof that the original longer-window copula is inferior.
Consecutive forecast horizons overlap; these are not 1,008 independent
outcomes per week. The twelve origins cover only a subset of the test dates
because the realised archive stops shortly after the delivery weeks.

A standalone LaTeX appendix replacement is included. Scores have been checked
against the saved CSV metrics at seed 3714.
